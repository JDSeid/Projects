package jrails;

public class Controller {
}