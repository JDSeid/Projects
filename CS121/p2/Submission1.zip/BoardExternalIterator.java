interface BoardExternalIterator {
    void visit(String loc, Piece p);
}