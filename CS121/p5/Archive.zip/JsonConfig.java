import java.util.*;

public class JsonConfig {
    public Map<String, List<String>> lines;
    public Map <String, List<String>> trips;

}
